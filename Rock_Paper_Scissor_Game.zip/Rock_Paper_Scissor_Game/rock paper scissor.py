import random

def rps_condition(player_choice,computer_choice):
    # rps conditions
    if player_choice >= 3 or player_choice < 0:
        print('**********XXX!!! You Have Entered An Invalid Number, You Lose !!!!XXX**********')
        next_game()
    elif player_choice == computer_choice:
        print('**********!!! Match Draw !!!**********')
    elif player_choice == 0 and computer_choice == 2:
        print(f'**********!!! {player_name} Win !!!**********')
    elif player_choice == 1 and computer_choice == 0:
        print(f'**********!!! {player_name} Win !!!**********')
    elif player_choice == 2 and computer_choice == 1:
        print(f'**********!!! {player_name} Win !!!**********')
    else:
        print('**********!!! Computer Win !!!**********')

def next_game():
    # next game
    for i in range(0, 10):
        next_game = str(input("Wanna Another Game Enter 'y', Otherwise 'n' : \n"))
        if next_game == 'y':
            rps()
        else:
            print('Exit')
def rps():
    # rps image
    rock = ("""
        _______
    ---'   ____)
          (_____)
          (_____)
          (____)
    ---.__(___)
    """)

    paper = ("""
         _______
    ---'    ____)____
               ______)
              _______)
             _______)
    ---.__________)
    """)

    scissor = ("""
        _______
    ---'   ____)____
              ______)
           __________)
          (____)
    ---.__(___)
    """)
    # rps image list
    game_images = [rock, paper, scissor]

    # player choice and computer choice input
    player_choice = int(input("Enter Your Choice : "))
    computer_choice = random.randint(0, 2)
    rps_condition(player_choice,computer_choice)

    # player image and computer image display
    player_print=game_images[player_choice]
    print(f'{player_name} Chose :\n{player_print}')
    computer_print = game_images[computer_choice]
    print(f'Computer Chose :\n{computer_print}')

# rps title image
print('''\n                                           
 /$$$$$$$   /$$$$$$   /$$$$$$  /$$   /$$       /$$$$$$$   /$$$$$$  /$$$$$$$  /$$$$$$$$ /$$$$$$$         /$$$$$$   /$$$$$$  /$$$$$$  /$$$$$$   /$$$$$$   /$$$$$$  /$$$$$$$ 
| $$__  $$ /$$__  $$ /$$__  $$| $$  /$$/      | $$__  $$ /$$__  $$| $$__  $$| $$_____/| $$__  $$       /$$__  $$ /$$__  $$|_  $$_/ /$$__  $$ /$$__  $$ /$$__  $$| $$__  $$
| $$  \ $$| $$  \ $$| $$  \__/| $$ /$$/       | $$  \ $$| $$  \ $$| $$  \ $$| $$      | $$  \ $$      | $$  \__/| $$  \__/  | $$  | $$  \__/| $$  \__/| $$  \ $$| $$  \ $$
| $$$$$$$/| $$  | $$| $$      | $$$$$/        | $$$$$$$/| $$$$$$$$| $$$$$$$/| $$$$$   | $$$$$$$/      |  $$$$$$ | $$        | $$  |  $$$$$$ |  $$$$$$ | $$  | $$| $$$$$$$/
| $$__  $$| $$  | $$| $$      | $$  $$        | $$____/ | $$__  $$| $$____/ | $$__/   | $$__  $$       \____  $$| $$        | $$   \____  $$ \____  $$| $$  | $$| $$__  $$
| $$  \ $$| $$  | $$| $$    $$| $$\  $$       | $$      | $$  | $$| $$      | $$      | $$  \ $$       /$$  \ $$| $$    $$  | $$   /$$  \ $$ /$$  \ $$| $$  | $$| $$  \ $$
| $$  | $$|  $$$$$$/|  $$$$$$/| $$ \  $$      | $$      | $$  | $$| $$      | $$$$$$$$| $$  | $$      |  $$$$$$/|  $$$$$$/ /$$$$$$|  $$$$$$/|  $$$$$$/|  $$$$$$/| $$  | $$
|__/  |__/ \______/  \______/ |__/  \__/      |__/      |__/  |__/|__/      |________/|__/  |__/       \______/  \______/ |______/ \______/  \______/  \______/ |__/  |__/
\n''')

# game instruction
print('Game Instructions :\nIf you Wanna Enter ROCK Enter 0\nIf you Wanna Enter PAPER Enter 1\nIf you Wanna Enter SCISSOR Enter 2')
print('**************************************************************************************************************************************************************************')

# player name
player_name=input('Enter Your Nickname : \n')
print(f'Hii {player_name}')
rps()
next_game()



